#ifndef CONFIGURATION_H
#define CONFIGURATION_H
#include "handle_ini.h"
#include "SFML/Audio.hpp"
typedef unsigned UINT;

class Configuration
{
    public:
    Handle_ini  cfile;
    string      ConfigFilename,
                ProgramName,
                ProgramPath,
                MicDevName,
                ErrorDesc="",
                FFTWindowing,
                ResultsDir,
                ScrShotsDir,
                CapSection="RecordingDevices";
    UINT        SampleRate,
                Averaging,
                FFTFS,
                WinWidthPercent,
                WinHeightPercent;
    float       MicSigMult;

    Configuration();
    virtual ~Configuration();

    bool    LoadConfig(std::string ConfigFilePath);
    bool    RefreshConfig();
    void    PrintUsage();

    private:
    UINT        RecDevNum;
};

#endif // CONFIGURATION_H
