#include <iostream>
#include <windows.h>
#include "Configuration.h"
#include "Scope.h"
// #define MAX_PATH 256

using namespace std;

int WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{

    char selfp[MAX_PATH];
    string pathprogram = "Failed to get path";
    DWORD szPath;
    szPath = GetModuleFileName(NULL, selfp, MAX_PATH);
    if(szPath !=0)
    {
        string helper = selfp;
        size_t pos = helper.find_last_of("\\");
        if(pos !=std::string::npos)
        {
            pathprogram = helper.substr(0, pos+1);
        }
    }

    Configuration cfg;
    if(!cfg.LoadConfig(pathprogram+"\\Config.ini")) { cout << cfg.ErrorDesc << endl; return 1; }
    Scope scp(cfg);
    if(scp.ErrorDesc!="") { cout << scp.ErrorDesc << endl; return 1; }
    scp.Start();
    (*scp.t).join();
    scp.Stop();
    return 0;
}
